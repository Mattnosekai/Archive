//
// compile with G++ 3.x or above:
// 		g++ -c cpplib.cpp -o cpplib.o
//		ar cr libcpplib.a cpplib.o
//
      
namespace cpp 
{
	int sum( int a, int b ) 
	{ 
		return a + b;
	}
}
