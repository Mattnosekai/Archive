


2007, August

Classic 1942� game clone.
ver. 0.55


This game/demo is simple clone of classic 1942� game series.
Rules are simple: shoot/destroy every enemy you can, for each You gain points.
Higher points - better place in high scores, that's all.

There are various types of enemies and several bonuses like power-up.
In bottom of screen is counter, that tells when special enemy - boss will appear.

More time You play -> more enemies will spawn.



Steering:
arrows -> move
Control -> shoot
Enter -> accept, next
Space Bar -> accept, next, shoot
Escape -> cancel, back



Options:
- Resolution: 512x384 or 640x480,
- Full screen: Yes or No (windowed mode),
- Desired FPS: 33 or 50,
- Collisions type: Simple (by rectangles, inaccurate) or Per-pixel (slower but accurate),
- Collisions rate: 10, 20, 30, 40 or 50 Per Second -> how oft check for collisions,
- Volume: 0 to 128 -> Max,




->> About source: <<-

from ver. 0.5 source is available to public
To compiling I use FB 0.17b
Currently most of comment's are in Polish, but I will translate them into English.
Many things in code are not properly explained (including sub's, variable names) this will change.



------------------
-->> Credits: <<--
------------------

game programmed by: DREAMERMAN - dreamerman@wp.pl
written in: FreeBasic Language - visit: www.freebasic.net
for graphic and user input using GfxLib2 -> built-in FB
for sound using SDL and SDL_mixer library's
graphic (under GPL license) taken from: SpriteLib GPL by Ari Feldman -> http://www.flyingyogi.com/fun/spritelib.html
most sounds taken from: www.grsites.com, other created/edited by me,
for wave's editing used Audacity -> http://audacity.sourceforge.net

project written in FbEdit -> http://fbedit.freebasic.net
archive/package made with 7zip -> www.7-zip.org



Thanks :)
